# ThinkPad X1 Tablet Gen 3: touch variant (plan)

Status: agreed approach, nothing built (2026-11-02). Device: X1 Tablet Gen 3, i5-8650U, 8 GB,
256 GB NVMe, 13" 3000×2000 touchscreen with Wacom AES pen, detachable folio keyboard. Windows 11
on it will be removed (erase-disk install) once the live test and the touch work are done.

## Approach (D-32)
- Not a fork and not a second image. One package, `brave-os-touch`, in the same repository and
  update channel, preinstalled from build 9 on and activated only when a touchscreen is present
  (plus a Settings toggle). The X1 Nano sees no change; tablet fixes ship as ordinary updates.
- Scope of the first cut, in order: output scale for 3000×2000 (likely 2×); an on-screen keyboard
  (squeekboard if labwc 0.8.3's input-method support and Brave's Wayland text input let it appear
  by itself, else wvkbd behind a panel button); rotation from the accelerometer (iio-sensor-proxy
  plus a small daemon driving `wlr-randr --transform`); larger panel, title bars and Settings
  buttons; Brave's touch-friendly tab strip. Later: tablet-mode detection from the folio, gestures.
- Out of scope: dual boot, fingerprint reader, LTE modem.

## Step 1: live test with the existing build 8 stick (no build)
Boot from the stick: with the folio attached press F12 at power-on; without it hold Volume Up
while pressing Power to reach the boot menu. Keep Secure Boot enabled. Then note, in Brave:

| Check | Expect | Note what you saw |
|---|---|---|
| Touch: tap a link, scroll a page, pinch to zoom, long-press for the context menu | all work | |
| Text size on the 3000×2000 panel | probably tiny: that is the scale item | |
| Folio keyboard and trackpoint, including after detaching and reattaching | work | |
| Pen: hover, tap, drag on a page | pointer follows the pen | |
| Wi-Fi: panel icon, join a network, load a page | works | |
| Brightness keys, volume keys, battery percentage | work | |
| Audio: play a video | sound | |
| Camera: a site that uses it (optional) | picture | |
| Suspend by power button, wake, screen back | works | |
| Rotate the tablet | nothing rotates yet (expected; the rotation item) | |
| Typing with the folio detached | no keyboard appears (expected; the OSK item) | |

Optional, one console line (Ctrl+Alt+F3, no login needed in the live session), then photograph
the screen: it lists the input devices, the orientation sensor and the exact model, which decides
how the touch package detects the hardware.

```
sudo sh -c 'grep "^N: Name" /proc/bus/input/devices; cat /sys/bus/iio/devices/*/name; cat /sys/class/dmi/id/product_version'
```

Ctrl+Alt+F7 (or F8) returns to the desktop.

## Step 1 result (build 8 live, 2026-11-02, owner report and console photo)
- Boots from the stick; touch works in Brave including pinch to zoom; Settings display scale 2×
  is enough touch optimisation for the owner. Audio (speakers and microphone) and Bluetooth did
  not work; under diagnosis (below). Wi-Fi, pen, folio and suspend not reported yet.
- Device readout: touchscreen and pen are `Wacom HID 511A Finger` / `Wacom HID 511A Pen` (hid-wacom);
  folio is `Chicony ThinkPad X1 Tablet Thin Keyboard Gen 3`; tablet-mode switch exists (`Intel
  Virtual Switches`, intel-vbtn); sensors present as IIO `accel_3d`, `gyro_3d`,
  `relative_orientation`, `gravity`, `als` (Intel sensor hub), so iio-sensor-proxy can drive
  rotation; audio jacks enumerate as `HDA Intel PCH Mic/Headphone/HDMI` (legacy HDA path probed);
  DMI product version `ThinkPad X1 Tablet Gen 3`.
- Audio hypotheses, in order of likelihood: the default output is one of the three HDMI/DP
  devices (fix: pick the analog output in Settings > Sound); the internal speakers/microphone sit
  behind the Intel DSP and need the SOF or SST path rather than legacy HDA (fix: driver option or
  topology firmware, decided from `/proc/asound/cards` and dmesg); a codec quirk.
- Bluetooth hypotheses: adapter soft-blocked by rfkill; Intel Bluetooth firmware (`intel/ibt-*`)
  missing from the image; the adapter never enumerated. `rfkill list`, `lsusb`, dmesg and
  `bluetoothctl list` decide.

## Step 1 diagnostics (second console photo)
- Audio controller probed by the legacy `snd_hda_intel` driver; codec `ALC295`, autoconfig
  `line_outs=2 (0x14/0x1b) type:speaker`, `speaker_outs=0`; no "DSP detected"/DMIC hand-over
  line, so no DSP driver is in play. Speakers silent, internal microphone dead. An ACPI SSDT named
  `HdaDsp` exists, so the platform was designed around Intel's audio DSP.
- Image facts: kernel 6.12 has `CONFIG_SND_SOC_SOF_KABYLAKE=m` (SOF for this generation) but
  `firmware-sof-signed 2025.01` ships no KBL firmware (`sof-kbl.ri` absent); the SST driver
  (`snd_soc_skl`) is not built in Debian's kernel. A DSP path would need third-party firmware.
- `lsusb`: folio keyboard, Sierra Wireless EM7455 LTE modem, Lite-On camera, the USB stick; no
  Intel Bluetooth device (`8087:…`) at all although Wi-Fi works. Most likely the BIOS switch
  (Security > I/O Port Access > Bluetooth) or Windows-side disablement; check in Windows 11's
  Device Manager or the BIOS before touching the image. `rfkill` is not in the image (add it).
- The folio keyboard's layout differs from the live console's US map (`|`, quotes), which broke two
  typed commands; diagnostics now go through a downloadable script
  (`tools/tablet-audio.sh` in the brave-os-apt repository) instead of long typed lines.

## Step 1 diagnostics, round two (tools/tablet-audio.sh v1, 2026-11-02)
- Bluetooth was disabled in the BIOS (Security > I/O Port Access). Enabled by the owner: the adapter
  now enumerates (`8087:0a2b Intel Bluetooth`), `thinkpad_acpi` reports the radio unblocked and
  BlueZ brings up controller `D0:AB:D5:49:26:B2`. Not an image defect; pairing to be confirmed.
- Audio: controller `8086:9d71` (Sunrise Point-LP), codec ALC295, **subsystem id 17aa:2263**,
  NHLT table present (digital microphones described to the DSP), SOF modules load
  (`snd_sof_pci_intel_skl`) but the legacy `snd_hda_intel` binds the device: Debian's dspcfg prefers
  SST for this generation only if the SST driver is built (it is not), SOF only on request
  (`dsp_driver=3`), and SOF would then need `sof-kbl.ri`, which Debian does not ship.
- Codec autoconfig: speakers on pins 0x14 and 0x1b (both `[Fixed] Speaker at Int`, EAPD on,
  OUT enabled), headphone 0x21, internal mic 0x12 (`[Fixed] Mic at Int`), jack mic 0x19. No entry
  for 17aa:2263 in the 6.12 Realtek quirk table. The script's own playback and capture test did
  not run (v1 used `runuser -u "#uid"`, which runuser rejects); v2 fixes that. Open hypotheses:
  (a) codec left in a state by Windows' driver that Linux does not reset ("speaker lost after
  reboot from Windows" is a known ALC295 pattern); a cold boot distinguishes it; (b) the speakers
  sit behind an amplifier the DSP firmware enables, in which case the legacy path can never drive
  them and the choice is third-party SOF firmware or no speakers; (c) a missing codec quirk.

## Step 1 outcome (2026-11-02)
- **Audio: resolved as hypothesis (a).** After a full power-off and a cold boot of the stick the
  speakers play. Windows' ALC295 driver leaves the codec in a state Linux's legacy HDA init does not
  undo; a warm reboot from Windows into Linux therefore has silent speakers. Once Windows is erased
  this cannot recur (every boot is a Linux boot). Recorded in docs/KNOWN-ISSUES.md for dual-OS
  USB testing. Internal microphone after a cold boot: to be confirmed by the owner.
- **Bluetooth: BIOS switch**, not the image. Pairing to be confirmed.
- Hardware verdict: nothing in the image needs changing for this device beyond the touch work;
  `rfkill` is added to build 9 for diagnostics.

## Step 2: the touch layer as a package (0.2.6, 2026-11-02)
Source: `appliance/touch/rootfs` and `packaging/brave-os-touch`, built by `scripts/build-debs.sh`
into `brave-os-touch`. Unit tests: `appliance/tests/test_touch.py` (decisions) and
`test_packaging.py` (package contents, session hooks).

What it does, and where each piece lives:

| Piece | Mechanism | Off switch |
|---|---|---|
| Activation | `touch-detect`: `touch.conf` `enabled=yes/no`, else udev `ID_INPUT_TOUCHSCREEN=1`. `touch-session` (labwc `autostart.d/50-touch`) marks `$XDG_RUNTIME_DIR/brave-os/touch-active` | Settings > Touch > Touch layer: Off |
| Tablet mode | root service `brave-os-tablet-mode` reads `SW_TABLET_MODE` (the X1 Tablet's "Intel Virtual Switches") with evdev ioctls, falls back to "no USB/Bluetooth keyboard", publishes `/run/brave-os/tablet-mode` | none needed; the file is advisory |
| On-screen keyboard | `tablet-mode-daemon` starts squeekboard in tablet mode and stops it in laptop mode (`keyboard=auto`); Brave gets `--enable-wayland-ime` so text fields raise it through labwc's text-input support; panel "Keyboard" button and Settings use `osk-toggle` (D-Bus `sm.puri.OSK0`) | `keyboard=never` |
| Rotation | `rotation-daemon`: `monitor-sensor --accel` (iio-sensor-proxy) to `wlr-randr --transform` on the internal output, tablet mode only, normal in laptop mode and on exit | `rotate=no` |
| Scale | `python3 -m brave_os.touch apply-scale` at session start: `scale=auto` is 2 on panels 2800 px and wider, 1.5 from 2000 px, else 1 | `scale=1|1.25|1.5|2` |
| Browser | `brave-os-open-brave` adds `--enable-wayland-ime --top-chrome-touch-ui=enabled` while `touch-active` exists (or `touch-detect` passes before the marker is written) | follows the layer |

Not in 0.2.6, on purpose: pen-specific settings (the Wacom pen already works as a pointer), palm
rejection tuning, a touch-specific labwc rc.xml (window buttons are usable at 2x), lock-screen
keyboard (swaylock has no on-screen keyboard; the live session has no lock, the installed system
needs the folio or a USB keyboard to unlock until this is solved; tracked in KNOWN-ISSUES).

Orientation mapping (`right-up` to transform 90, `left-up` to 270) is inferred from the wl_output
counter-clockwise convention and not yet verified on the device; if the picture turns the wrong way
the fix is one line in `touch.py` and a channel update.

The X1 Nano is not affected: the channel upgrades installed packages only, and `brave-os-touch` is
not installed there. If it ever were, `enabled=auto` sees no touchscreen and does nothing.

Verification plan for this step: VM with `VM_TOUCH=1` (QEMU `virtio-multitouch-pci`, so udev reports
a touchscreen) on an installed disk upgraded to 0.2.6 plus `brave-os-touch`: panel button appears,
squeekboard appears on a tapped text field, scale and transform apply through wlr-randr. Then build
9 and the tablet live test.

### Step 2 results (VM, 2026-11-02)
On the build 8 installed VM with a virtual touchscreen (TEST-REPORT.md "Touch layer (0.2.6)",
reports/touch/vm-0.2.6-touch.txt): install from the signed repository, hardware gating, browser
flags, the panel button, the keyboard rising on a text field and typing through it, scale 2,
rotation from a sensor feed in tablet mode, and Settings > Touch are VM-PASS. One defect was found
and fixed before publication: `touch-session` signalled waybar at login and killed it (the panel
was missing); it no longer signals anything. Two harness caveats (VT switching revokes DRM master;
QEMU touch taps do not complete clicks) are recorded in the evidence file and KNOWN-ISSUES.
Open for hardware: rotation direction, the real tablet-mode switch, the 2x default on the 3000 px
panel, and the lock screen without a keyboard (KNOWN-ISSUES).

## Step 3: installed on the tablet (2026-11-02, owner report)
Build 9 installed on the X1 Tablet Gen 3 (Windows erased). Owner's verdict: "everything works
perfectly except auto rotation, which rotates the display in the wrong direction." That is the
mirrored mapping flagged in step 2: `right-up`/`left-up` were 90/270 and need 270/90. Fixed in
0.2.7 (`touch.py`, one line, unit test updated) and shipped through the channel; the tablet picks
it up with its next update run (docs/UPDATES.md "When updates do not arrive" for the one-time pull
on a machine that is on battery when the timer fires).
HARDWARE-PASS by owner report: keyboard, 2x, touch, install; rotation direction FAIL in 0.2.6,
fix pending the owner's confirmation on 0.2.7. Still open: lock screen without a keyboard
(KNOWN-ISSUES), the folio-detached tablet-mode switch (works per the report, not separately
recorded), Bluetooth pairing and microphone (not reported either way).

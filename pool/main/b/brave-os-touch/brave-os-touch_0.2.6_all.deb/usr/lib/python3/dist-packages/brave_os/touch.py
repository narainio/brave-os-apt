"""brave-os-touch: the touch layer's decisions as plain functions (no GTK, no D-Bus), so the daemons
stay thin and the logic is unit-tested. Shared config: ~/.config/brave-os/touch.conf (seeded from
/etc/brave-os/defaults/touch.conf by seed-user-config).

  enabled   auto|yes|no      auto = a touchscreen is present (udev ID_INPUT_TOUCHSCREEN)
  keyboard  auto|always|never  on-screen keyboard (squeekboard): auto = only in tablet mode
  rotate    yes|no           follow the accelerometer (iio-sensor-proxy) in tablet mode
  scale     auto|1|1.25|1.5|2  output scale of the internal panel; auto = by panel width

CLI (used by the shell parts): python3 -m brave_os.touch apply-scale | show-config
"""
import os
import re
import subprocess
import sys

from brave_os.settings_logic import atomic_write, parse_kv

TOUCH_DEFAULTS = {"enabled": "auto", "keyboard": "auto", "rotate": "yes", "scale": "auto"}
TOUCH_CHOICES = {
    "enabled": ("auto", "yes", "no"),
    "keyboard": ("auto", "always", "never"),
    "rotate": ("yes", "no"),
    "scale": ("auto", "1", "1.25", "1.5", "2"),
}
# iio-sensor-proxy orientation -> wl_output transform. The protocol counts counter-clockwise:
# a device turned counter-clockwise has its right edge up and needs transform 90. Verified on
# hardware only once the tablet runs it; swapping 90/270 is a one-line update if it is mirrored.
ORIENTATION_TO_TRANSFORM = {"normal": "normal", "bottom-up": "180", "right-up": "90", "left-up": "270"}
INTERNAL_PREFIXES = ("eDP", "LVDS", "DSI")


def config_path():
    return os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config"), "brave-os", "touch.conf")


def load_touch(path):
    vals = dict(TOUCH_DEFAULTS)
    try:
        with open(path, encoding="utf-8") as fh:
            kv = parse_kv(fh.read())
    except OSError:
        return vals
    for k, choices in TOUCH_CHOICES.items():
        v = kv.get(k, vals[k]).strip().lower()
        if v in choices:
            vals[k] = v
    return vals


def save_touch(path, values):
    vals = dict(TOUCH_DEFAULTS)
    for k, choices in TOUCH_CHOICES.items():
        v = str(values.get(k, vals[k])).strip().lower()
        if v not in choices:
            raise ValueError(f"{k}={v} not allowed")
        vals[k] = v
    text = "# brave-os touch layer. Edited by Settings > Touch. See /usr/share/doc/brave-os/TABLET.md.\n" + "".join(f"{k}={vals[k]}\n" for k in TOUCH_CHOICES)
    atomic_write(path, text)
    return vals


def touchscreen_in_udev_db(text):
    """True if udevadm's export-db lists a touchscreen."""
    return re.search(r"^E: ID_INPUT_TOUCHSCREEN=1$", text, re.M) is not None


def external_keyboard_in_udev_db(text):
    """True if a USB or Bluetooth keyboard is attached (the fallback for machines without a
    tablet-mode switch). The built-in AT keyboard and virtual devices do not count."""
    for block in text.split("\n\n"):
        if re.search(r"^E: ID_INPUT_KEYBOARD=1$", block, re.M) and re.search(r"^E: ID_BUS=(usb|bluetooth)$", block, re.M):
            return True
    return False


def effective_enabled(conf, hw_present):
    return {"yes": True, "no": False}.get(conf.get("enabled", "auto"), bool(hw_present))


def transform_for(orientation):
    return ORIENTATION_TO_TRANSFORM.get(orientation)


def parse_monitor_sensor_line(line):
    """Orientation from a monitor-sensor line, or None."""
    m = re.search(r"orientation(?: changed)?:\s*([a-z-]+)", line)
    return m.group(1) if m else None


def parse_wlr_randr(text):
    """[{name, enabled, width, height, scale, transform}] from `wlr-randr` output."""
    outs, cur = [], None
    for line in text.splitlines():
        if line and not line[0].isspace():
            cur = {"name": line.split()[0], "enabled": True, "width": 0, "height": 0, "scale": 1.0, "transform": "normal"}
            outs.append(cur)
        elif cur is not None:
            s = line.strip()
            if s.startswith("Enabled:"):
                cur["enabled"] = s.split(":", 1)[1].strip() == "yes"
            elif "current" in s and "px" in s:
                m = re.match(r"(\d+)x(\d+)", s)
                if m:
                    cur["width"], cur["height"] = int(m.group(1)), int(m.group(2))
            elif s.startswith("Scale:"):
                try:
                    cur["scale"] = float(s.split(":", 1)[1])
                except ValueError:
                    pass
            elif s.startswith("Transform:"):
                cur["transform"] = s.split(":", 1)[1].strip()
    return outs


def internal_output(outputs):
    enabled = [o for o in outputs if o.get("enabled", True)]
    for o in enabled:
        if o["name"].startswith(INTERNAL_PREFIXES):
            return o
    return enabled[0] if enabled else None


def default_scale(width_px):
    """2x above 2800 px wide (3000x2000 tablet panels), 1.5x above 2000, else 1."""
    if width_px >= 2800:
        return "2"
    if width_px >= 2000:
        return "1.5"
    return "1"


def wanted_scale(conf, width_px):
    return default_scale(width_px) if conf.get("scale", "auto") == "auto" else conf["scale"]


def tablet_mode_from_switch_bits(bits):
    """SW_TABLET_MODE (bit 1) from the EVIOCGSW bitmap bytes."""
    return bool(len(bits) > 0 and (bits[0] >> 1) & 1)


def decide_tablet_mode(switch_state, external_keyboard):
    """switch_state: True/False from SW_TABLET_MODE, None if the machine has no switch."""
    if switch_state is not None:
        return bool(switch_state)
    return not external_keyboard


def keyboard_wanted(conf, tablet_mode):
    policy = conf.get("keyboard", "auto")
    if policy == "always":
        return True
    if policy == "never":
        return False
    return bool(tablet_mode)


# ---- CLI helpers used by the shell scripts -----------------------------------------------------

def _run(argv):
    return subprocess.run(argv, capture_output=True, text=True, timeout=20)


def cmd_apply_scale():
    conf = load_touch(config_path())
    r = _run(["wlr-randr"])
    if r.returncode != 0:
        print("wlr-randr failed:", r.stderr.strip(), file=sys.stderr)
        return 1
    out = internal_output(parse_wlr_randr(r.stdout))
    if not out:
        return 1
    want = wanted_scale(conf, out["width"])
    if abs(float(want) - float(out["scale"])) < 0.01:
        print(f"{out['name']}: scale {want} already set")
        return 0
    r = _run(["wlr-randr", "--output", out["name"], "--scale", want])
    print(f"{out['name']}: scale {out['scale']} -> {want} ({'ok' if r.returncode == 0 else r.stderr.strip()})")
    return r.returncode


def main(argv):
    if len(argv) > 1 and argv[1] == "apply-scale":
        return cmd_apply_scale()
    if len(argv) > 1 and argv[1] == "show-config":
        for k, v in load_touch(config_path()).items():
            print(f"{k}={v}")
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))

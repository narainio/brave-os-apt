# Changelog

Versions are `BRAVE_OS_VERSION` in `config/release.conf`; the same number names the appliance
packages and the image. Dates are UTC.

## 0.2.7 (2026-11-02)

- Rotation direction: `right-up` now maps to transform 270 and `left-up` to 90 (0.2.6 had them the
  other way round; the X1 Tablet turned the picture the wrong way, owner report after the install).
- Updates on battery: `Unattended-Upgrade::OnlyOnACPower` is now false. The daily run fires at 06:00
  or at the next wake, and a laptop that is unplugged at that moment installed nothing, which is
  why the X1 Nano never received 0.2.5 and 0.2.6. Metered connections are still skipped.
- Settings > System gains "Install updates now": refreshes the lists and runs the same
  unattended-upgrade as the daily timer, regardless of battery, after the usual authentication
  (`apt-upgrade-helper`, polkit action `org.brave-os.apt-upgrade`). "Check for updates now" lists
  `brave-os-touch` too and says when the machine is on battery.

## 0.2.6 (2026-11-02)

- New package `brave-os-touch` (D-32): on-screen keyboard (squeekboard) in tablet mode, rotation
  from the accelerometer (iio-sensor-proxy), a 2x default scale on 3000 px wide panels, touch
  browser flags, a panel "Keyboard" button and Settings > Touch. It does nothing on machines without
  a touchscreen (`enabled=auto`), and the update channel does not add it to machines that do not
  have it: it ships in the image from build 9 and can be installed by hand on earlier installs.
- `brave-os-session`: labwc autostart runs hooks from `/usr/libexec/brave-os/autostart.d/`;
  `seed-user-config` copies every `/etc/brave-os/defaults/*.conf`; `brave-os-open-brave` adds
  `--enable-wayland-ime --top-chrome-touch-ui=enabled` while the touch layer is active; the panel
  gains `custom/keyboard` (hidden unless the touch layer is active). No change on the X1 Nano.
- Image build 9 adds squeekboard, iio-sensor-proxy and rfkill to the package list (squeekboard
  brings feedbackd and gnome-desktop data, about 3 MB).

## 0.2.5 (2026-11-01)

- Panel: the window list shows one icon per window instead of icon plus a 32-character title, so
  many open Brave windows no longer push the clock and the right-hand items off the screen (owner's
  first nit from daily use). The title is still shown on hover; the active window stays highlighted.

## 0.2.4 (2026-11-01)

- Documentation only: docs/UPDATES.md explains the Build and Packages lines in Settings > System and
  names the current adoption files. Published to exercise the update path on the first image built
  with packages (build 8).

## 0.2.3 (2026-11-01)

- `brave-os-session` no longer ships `/etc/apt/apt.conf.d/20auto-upgrades`; unattended-upgrades
  writes that file itself and the duplicate made dpkg prompt during the image build. The autoclean
  interval moved into `52brave-os-unattended-upgrades`.

## 0.2.2 (2026-11-01)

- `brave-os-session` diverts waybar's `/etc/xdg/waybar/style.css` instead of overwriting it; 0.2.0
  and 0.2.1 could not be installed next to Debian's waybar package (dpkg refused the shared path).

## 0.2.1 (2026-11-01)

- Settings > System lists the installed brave-os package versions.
- `brave-os-session` no longer depends on `psmisc`, which build 7 did not ship, so adopting the
  packages on a build 7 machine needs nothing from the Debian mirrors.

## 0.2.0 (2026-11-01)

- The session, panel, Settings, idle and power policy, Downloads retention, installer launcher and
  update policy now ship as the `brave-os-session` package; `brave-os-archive-keyring` carries the
  signed brave-os repository. Installed machines receive future versions through
  unattended-upgrades (docs/UPDATES.md, D-29).
- The panel and Settings > System show "Restart needed" after a brave-os update until a new session
  starts; Settings > System > Check for updates now lists the brave-os packages.
- Images before 0.2.0 need the one-time adoption in docs/UPDATES.md.

## 0.1.0-prototype, builds 1 to 7 (2026-10-05)

- First images: Debian 13.7, labwc, Brave Origin, Calamares erase-disk LUKS install. Verified in
  VMs; build 7 published and installed on the X1 Nano.

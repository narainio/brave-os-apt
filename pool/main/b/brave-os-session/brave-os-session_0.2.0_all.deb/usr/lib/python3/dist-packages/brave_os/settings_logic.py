"""Pure logic for the curated settings menu (unit-tested without GTK)."""
import os
import re
import xml.etree.ElementTree as ET

POWER_CHOICES = {
    "lock_minutes": (0, 1, 2, 5, 10, 15, 30, 60),
    "screen_off_minutes": (0, 5, 10, 15, 20, 30, 60),
    "suspend_on_battery_minutes": (0, 10, 15, 20, 30, 45, 60),
    "suspend_on_ac_minutes": (0, 30, 60, 120),
}
POWER_DEFAULTS = {"lock_minutes": 10, "screen_off_minutes": 15, "suspend_on_battery_minutes": 30, "suspend_on_ac_minutes": 0}
INPUT_DEFAULTS = {"tap": True, "natural_scroll": True, "pointer_speed": 0.0, "click_method": "clickfinger"}
LAYOUT_RE = re.compile(r"^[a-z]{2,3}(\([a-z0-9_-]+\))?(,[a-z]{2,3}(\([a-z0-9_-]+\))?)?$")


def atomic_write(path, text, mode=0o644):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.tmp.{os.getpid()}"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(text)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def parse_kv(text):
    out = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def load_power(path):
    vals = dict(POWER_DEFAULTS)
    try:
        with open(path, encoding="utf-8") as fh:
            kv = parse_kv(fh.read())
    except OSError:
        return vals
    for k, choices in POWER_CHOICES.items():
        try:
            v = int(kv.get(k, vals[k]))
        except ValueError:
            continue
        if v in choices:
            vals[k] = v
    return vals


def save_power(path, values):
    vals = dict(POWER_DEFAULTS)
    for k, choices in POWER_CHOICES.items():
        v = int(values.get(k, vals[k]))
        if v not in choices:
            raise ValueError(f"{k}={v} not allowed")
        vals[k] = v
    text = "# brave-os idle/power policy (minutes; 0 disables). Edited by Settings.\n" + "".join(f"{k}={vals[k]}\n" for k in POWER_CHOICES)
    atomic_write(path, text)
    return vals


def validate_layout(layout, base_lst_text=None):
    layout = (layout or "").strip()
    if not LAYOUT_RE.match(layout):
        return False
    if base_lst_text:
        known = set()
        section = None
        for line in base_lst_text.splitlines():
            if line.startswith("!"):
                section = line.strip()
                continue
            if section == "! layout" and line.strip():
                known.add(line.split()[0])
        if known:
            return all(part.split("(")[0] in known for part in layout.split(","))
    return True


def set_layout(env_path, layout):
    if not validate_layout(layout):
        raise ValueError("invalid keyboard layout")
    lines = []
    try:
        with open(env_path, encoding="utf-8") as fh:
            lines = [l.rstrip("\n") for l in fh]
    except OSError:
        pass
    lines = [l for l in lines if not l.startswith("XKB_DEFAULT_LAYOUT=")]
    lines.append(f"XKB_DEFAULT_LAYOUT={layout}")
    atomic_write(env_path, "\n".join(lines) + "\n")


def get_layout(env_path, default="us"):
    try:
        with open(env_path, encoding="utf-8") as fh:
            kv = parse_kv(fh.read())
    except OSError:
        return default
    return kv.get("XKB_DEFAULT_LAYOUT", default)


def _yesno(b):
    return "yes" if b else "no"


def load_input(rc_path):
    vals = dict(INPUT_DEFAULTS)
    try:
        tree = ET.parse(rc_path)
    except (OSError, ET.ParseError):
        return vals
    for dev in tree.getroot().iterfind("./libinput/device"):
        if dev.get("category") != "touchpad":
            continue
        t = dev.findtext("tap")
        if t:
            vals["tap"] = t.strip().lower() == "yes"
        n = dev.findtext("naturalScroll")
        if n:
            vals["natural_scroll"] = n.strip().lower() == "yes"
        s = dev.findtext("pointerSpeed")
        if s:
            try:
                vals["pointer_speed"] = max(-1.0, min(1.0, float(s)))
            except ValueError:
                pass
        c = dev.findtext("clickMethod")
        if c in ("clickfinger", "buttonAreas", "none"):
            vals["click_method"] = c
    return vals


def save_input(rc_path, tap, natural_scroll, pointer_speed, click_method="clickfinger"):
    """Write only a <libinput> touchpad block into the user's rc.xml, preserving other elements.
    labwc -m merges this over /etc/xdg/labwc/rc.xml, so keybindings are never lost."""
    speed = max(-1.0, min(1.0, float(pointer_speed)))
    if click_method not in ("clickfinger", "buttonAreas", "none"):
        raise ValueError("bad click method")
    root = None
    try:
        root = ET.parse(rc_path).getroot()
        if root.tag != "labwc_config":
            root = None
    except (OSError, ET.ParseError):
        root = None
    if root is None:
        root = ET.Element("labwc_config")
    li = root.find("libinput")
    if li is None:
        li = ET.SubElement(root, "libinput")
    for dev in list(li.findall("device")):
        if dev.get("category") == "touchpad":
            li.remove(dev)
    dev = ET.SubElement(li, "device", {"category": "touchpad"})
    ET.SubElement(dev, "tap").text = _yesno(tap)
    ET.SubElement(dev, "naturalScroll").text = _yesno(natural_scroll)
    ET.SubElement(dev, "disableWhileTyping").text = "yes"
    ET.SubElement(dev, "clickMethod").text = click_method
    ET.SubElement(dev, "pointerSpeed").text = f"{speed:.2f}"
    ET.indent(root, space="  ")
    text = '<?xml version="1.0"?>\n<!-- user overrides written by brave-os Settings; merged over /etc/xdg/labwc/rc.xml -->\n' + ET.tostring(root, encoding="unicode") + "\n"
    atomic_write(rc_path, text)
    return load_input(rc_path)


def parse_power_profiles(output):
    """Parse `powerprofilesctl list` output -> (active, [profiles])."""
    active, profiles = None, []
    for line in output.splitlines():
        s = line.strip()
        if s.endswith(":") and not s.startswith(("CpuDriver", "PlatformDriver", "Degraded")):
            name = s.rstrip(":").lstrip("* ").strip()
            if name and " " not in name:
                profiles.append(name)
                if line.strip().startswith("*"):
                    active = name
    return active, profiles


def read_release(path="/etc/brave-os/release"):
    try:
        with open(path, encoding="utf-8") as fh:
            return {k: v.strip('"') for k, v in parse_kv(fh.read()).items()}
    except OSError:
        return {}


def restart_state(status_cmd="/usr/libexec/brave-os/updates-status"):
    """(restart_needed, reason) from the updates-status helper, the single place that decides whether
    a reboot (Debian) or a sign-out (brave-os-session update) is pending. Falls back to the Debian
    flag file if the helper is unavailable."""
    import json
    import subprocess
    try:
        out = subprocess.run([status_cmd], capture_output=True, text=True, timeout=5).stdout
        d = json.loads(out or "{}")
        return d.get("class") == "restart", str(d.get("tooltip", ""))
    except (OSError, ValueError, subprocess.SubprocessError):
        return os.path.exists("/var/run/reboot-required"), ""

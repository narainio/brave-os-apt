"""brave-os appliance helpers (cleanup utility, settings logic)."""

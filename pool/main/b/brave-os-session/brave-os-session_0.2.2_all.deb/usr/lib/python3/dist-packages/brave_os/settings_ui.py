"""Curated settings menu for brave-os (GTK 3). Opens existing controls; owns only small forms.
Not a settings framework: every entry maps to one external tool or one validated config write."""
import os
import subprocess
import sys

from brave_os import settings_logic as L

try:
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, GLib
except Exception as e:  # pragma: no cover - GTK missing in unit tests
    Gtk = None
    _IMPORT_ERROR = e

CFG = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "brave-os")
LABWC_USER = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "labwc")
IS_LIVE = os.path.exists("/run/brave-os/live")


def launch(*argv):
    try:
        subprocess.Popen(argv, start_new_session=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as e:
        return str(e)
    return None


def capture(argv, timeout=120):
    try:
        r = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        return (r.stdout + r.stderr).strip() or f"(exit {r.returncode})"
    except Exception as e:
        return f"error: {e}"


def has(cmd):
    return any(os.access(os.path.join(p, cmd), os.X_OK) for p in os.environ.get("PATH", "/usr/bin:/bin").split(":"))


ENTRIES = [
    ("Wi-Fi & network", "Saved connections and VPN (nm-connection-editor). Choose networks from the panel icon.", ("tool", "nm-connection-editor")),
    ("Bluetooth", "Pair and connect devices (blueman).", ("tool", "blueman-manager")),
    ("Sound", "Output, input, volume and microphone (pavucontrol).", ("tool", "pavucontrol")),
    ("Displays", "Scale, resolution and arrangement (wdisplays). Not remembered across hot-plug in this prototype.", ("tool", "wdisplays")),
    ("Touchpad & keyboard", "Tap to click, natural scrolling, pointer speed, keyboard layout.", ("page", "input")),
    ("Power & lock", "Idle lock, screen off, suspend on battery, power profile.", ("page", "power")),
    ("Downloads retention", "Pause the 30-day cleanup, see what it would do.", ("page", "retention")),
    ("System", "Updates, restart, shut down, about" + (", install to internal disk" if IS_LIVE else "") + ".", ("page", "system")),
]


class Settings(Gtk.Window if Gtk else object):
    def __init__(self, page=None):
        super().__init__(title="Settings")
        self.set_default_size(600, 660)
        self.set_border_width(12)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.add(box)
        lb = Gtk.ListBox()
        lb.set_selection_mode(Gtk.SelectionMode.NONE)
        for title, sub, action in ENTRIES:
            if action[0] == "tool" and not has(action[1]):
                sub = f"Unavailable: {action[1]} is not installed."
            row = Gtk.ListBoxRow()
            h = Gtk.Box(spacing=10, margin=6)
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            t = Gtk.Label(label=title, xalign=0)
            t.get_style_context().add_class("title")
            s = Gtk.Label(label=sub, xalign=0, wrap=True)
            s.get_style_context().add_class("dim-label")
            v.pack_start(t, False, False, 0)
            v.pack_start(s, False, False, 0)
            b = Gtk.Button(label="Open")
            b.connect("clicked", self.on_open, action)
            b.set_sensitive(not (action[0] == "tool" and not has(action[1])))
            h.pack_start(v, True, True, 0)
            h.pack_end(b, False, False, 0)
            row.add(h)
            lb.add(row)
        sw = Gtk.ScrolledWindow()
        sw.add(lb)
        box.pack_start(sw, True, True, 0)
        note = Gtk.Label(label="Downloads are temporary. Eligible files are permanently deleted after 30 days. Opening or renaming does not extend retention.", wrap=True, xalign=0)
        note.get_style_context().add_class("dim-label")
        box.pack_start(note, False, False, 0)
        self.show_all()
        if page:
            GLib.idle_add(self.open_page, page)

    def on_open(self, _b, action):
        kind, target = action
        if kind == "tool":
            err = launch(target)
            if err:
                self.msg(f"Could not start {target}: {err}")
        else:
            self.open_page(target)

    def open_page(self, page):
        {"input": self.page_input, "power": self.page_power, "retention": self.page_retention, "system": self.page_system}[page]()
        return False

    def msg(self, text):
        d = Gtk.MessageDialog(transient_for=self, modal=True, buttons=Gtk.ButtonsType.OK, text=text)
        d.run()
        d.destroy()

    def dialog(self, title):
        d = Gtk.Dialog(title=title, transient_for=self, modal=True)
        d.add_button("Close", Gtk.ResponseType.CLOSE)
        d.set_default_size(480, 360)
        grid = Gtk.Grid(row_spacing=8, column_spacing=12, margin=12)
        d.get_content_area().pack_start(grid, True, True, 0)
        return d, grid

    # --- Touchpad & keyboard ------------------------------------------------
    def page_input(self):
        rc = os.path.join(LABWC_USER, "rc.xml")
        env = os.path.join(LABWC_USER, "environment")
        cur = L.load_input(rc)
        d, g = self.dialog("Touchpad & keyboard")
        tap = Gtk.Switch(active=cur["tap"], halign=Gtk.Align.START)
        nat = Gtk.Switch(active=cur["natural_scroll"], halign=Gtk.Align.START)
        spd = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, -1.0, 1.0, 0.1)
        spd.set_value(cur["pointer_speed"])
        spd.set_hexpand(True)
        lay = Gtk.Entry(text=L.get_layout(env))
        rows = [("Tap to click", tap), ("Natural scrolling", nat), ("Pointer speed", spd), ("Keyboard layout (e.g. us, gb, de)", lay)]
        for i, (lbl, w) in enumerate(rows):
            g.attach(Gtk.Label(label=lbl, xalign=0), 0, i, 1, 1)
            g.attach(w, 1, i, 1, 1)
        status = Gtk.Label(label="", xalign=0, wrap=True)
        g.attach(status, 0, len(rows), 2, 1)
        apply_b = Gtk.Button(label="Apply")

        def do_apply(_b):
            try:
                L.save_input(rc, tap.get_active(), nat.get_active(), spd.get_value())
                layout = lay.get_text().strip()
                base = None
                try:
                    with open("/usr/share/X11/xkb/rules/base.lst", encoding="utf-8") as fh:
                        base = fh.read()
                except OSError:
                    pass
                if not L.validate_layout(layout, base):
                    status.set_text("Keyboard layout not recognised; touchpad settings applied, layout unchanged.")
                else:
                    L.set_layout(env, layout)
                    status.set_text("Applied. Touchpad changes are live; the keyboard layout applies at next login.")
                capture(["labwc", "--reconfigure"], timeout=10)
            except (OSError, ValueError) as e:
                status.set_text(f"Could not apply: {e}")
        apply_b.connect("clicked", do_apply)
        g.attach(apply_b, 1, len(rows) + 1, 1, 1)
        d.show_all()
        d.run()
        d.destroy()

    # --- Power & lock ---------------------------------------------------------
    def page_power(self):
        path = os.path.join(CFG, "power.conf")
        cur = L.load_power(path)
        d, g = self.dialog("Power & lock")
        combos = {}
        labels = {"lock_minutes": "Lock after idle (minutes)", "screen_off_minutes": "Turn screen off after (minutes)",
                  "suspend_on_battery_minutes": "Suspend on battery after (minutes)", "suspend_on_ac_minutes": "Suspend on AC after (minutes)"}
        i = 0
        for key, choices in L.POWER_CHOICES.items():
            c = Gtk.ComboBoxText()
            for v in choices:
                c.append(str(v), "never" if v == 0 else str(v))
            c.set_active_id(str(cur[key]))
            combos[key] = c
            g.attach(Gtk.Label(label=labels[key], xalign=0), 0, i, 1, 1)
            g.attach(c, 1, i, 1, 1)
            i += 1
        prof = Gtk.ComboBoxText()
        active, profiles = (None, [])
        if has("powerprofilesctl"):
            active, profiles = L.parse_power_profiles(capture(["powerprofilesctl", "list"], timeout=10))
        for p in profiles:
            prof.append(p, p)
        if active:
            prof.set_active_id(active)
        prof.set_sensitive(bool(profiles))
        g.attach(Gtk.Label(label="Power profile" + ("" if profiles else " (unsupported here)"), xalign=0), 0, i, 1, 1)
        g.attach(prof, 1, i, 1, 1)
        i += 1
        g.attach(Gtk.Label(label="Lid close: suspend (ignored when docked with an external display). The screen always locks before sleep. Video calls and playback inhibit idle actions when the browser requests it.", xalign=0, wrap=True), 0, i, 2, 1)
        i += 1
        status = Gtk.Label(label="", xalign=0)
        g.attach(status, 0, i, 2, 1)
        i += 1
        b = Gtk.Button(label="Apply")

        def do_apply(_b):
            try:
                L.save_power(path, {k: int(c.get_active_id()) for k, c in combos.items()})
                launch("/usr/libexec/brave-os/idle-daemon")
                if profiles and prof.get_active_id() and prof.get_active_id() != active:
                    capture(["powerprofilesctl", "set", prof.get_active_id()], timeout=10)
                status.set_text("Applied.")
            except (OSError, ValueError) as e:
                status.set_text(f"Could not apply: {e}")
        b.connect("clicked", do_apply)
        g.attach(b, 1, i, 1, 1)
        d.show_all()
        d.run()
        d.destroy()

    # --- Downloads retention --------------------------------------------------
    def page_retention(self):
        from brave_os import cleanup as C
        cfg_path = os.path.join(CFG, "cleanup.conf")
        cfg = C.load_config(cfg_path)
        d, g = self.dialog("Downloads retention")
        g.attach(Gtk.Label(label="Downloads are temporary. Eligible files are permanently deleted after 30 days. Opening or renaming does not extend retention. Files first seen by the cleanup less than 30 days ago are always kept (safety grace).", xalign=0, wrap=True), 0, 0, 2, 1)
        sw = Gtk.Switch(active=cfg["paused"], halign=Gtk.Align.START)
        g.attach(Gtk.Label(label="Pause automatic deletion", xalign=0), 0, 1, 1, 1)
        g.attach(sw, 1, 1, 1, 1)
        out = Gtk.TextView(editable=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD)
        s = Gtk.ScrolledWindow(hexpand=True, vexpand=True)
        s.add(out)
        g.attach(s, 0, 2, 2, 1)
        b = Gtk.Button(label="Check now (dry run, deletes nothing)")

        def do_check(_b):
            out.get_buffer().set_text(capture(["brave-os-staging-cleanup", "status"], timeout=300))
        b.connect("clicked", do_check)
        g.attach(b, 0, 3, 2, 1)

        def toggled(w, _p):
            C.write_config(cfg_path, w.get_active(), cfg["accepted_root"])
        sw.connect("notify::active", toggled)
        d.show_all()
        d.run()
        d.destroy()

    # --- System -----------------------------------------------------------------
    def page_system(self):
        d, g = self.dialog("System")
        rel = L.read_release()
        br = L.read_release("/etc/brave-os/browser.env")
        about = (f"{rel.get('BRAVE_OS_PRETTY_NAME', 'brave-os')} {rel.get('BRAVE_OS_VERSION', '?')} ({rel.get('BRAVE_OS_LABEL', '')})\n"
                 f"Build {rel.get('BRAVE_OS_BUILD_ID', '?')}, Debian {rel.get('BRAVE_OS_CODENAME', '?')}, source {rel.get('BRAVE_OS_GIT', '?')}\n"
                 f"Browser: {br.get('BRAVE_PACKAGE', '?')} at {br.get('BRAVE_BIN', '?')}\n"
                 + ("LIVE SESSION: nothing persists after reboot." if IS_LIVE else "Installed system."))
        pk = L.package_versions(("brave-os-session", "brave-os-archive-keyring"))
        if pk:
            about += "\nPackages: " + ", ".join(f"{n} {v}" for n, v in pk)
        g.attach(Gtk.Label(label=about, xalign=0, wrap=True, selectable=True), 0, 0, 3, 1)
        out = Gtk.TextView(editable=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD)
        s = Gtk.ScrolledWindow(hexpand=True, vexpand=True)
        s.add(out)
        g.attach(s, 0, 1, 3, 1)
        restart_needed, why = L.restart_state()
        out.get_buffer().set_text((why or "Restart needed to finish applying updates.") if restart_needed else "No restart pending. Updates install automatically in the background; the browser is never closed by an update.")
        chk = Gtk.Button(label="Check for updates now")
        chk.set_sensitive(not IS_LIVE)

        def do_check(_b):
            out.get_buffer().set_text("Checking (authentication may be requested)...")
            GLib.idle_add(lambda: out.get_buffer().set_text(capture(["pkexec", "/usr/libexec/brave-os/apt-update-helper"], timeout=600)) or False)
        chk.connect("clicked", do_check)
        g.attach(chk, 0, 2, 1, 1)
        files_b = Gtk.Button(label="Files")
        files_b.connect("clicked", lambda _b: launch("brave-os-files"))
        g.attach(files_b, 1, 2, 1, 1)
        brave_b = Gtk.Button(label="Open Brave")
        brave_b.connect("clicked", lambda _b: launch("brave-os-open-brave"))
        g.attach(brave_b, 2, 2, 1, 1)
        row = 3
        if IS_LIVE:
            inst = Gtk.Button(label="Install to internal disk…")
            inst.connect("clicked", lambda _b: launch("brave-os-install"))
            g.attach(inst, 0, row, 3, 1)
            row += 1
        for label, action in (("Restart", "reboot"), ("Shut down", "poweroff"), ("Log out", "logout")):
            b = Gtk.Button(label=label)
            b.connect("clicked", self.confirm_power, label, action)
            g.attach(b, ("Restart", "Shut down", "Log out").index(label), row, 1, 1)
        d.show_all()
        d.run()
        d.destroy()

    def confirm_power(self, _b, label, action):
        q = Gtk.MessageDialog(transient_for=self, modal=True, buttons=Gtk.ButtonsType.OK_CANCEL, text=f"{label} now?",
                              secondary_text="Unsaved browser tabs are restored by Brave on next start.")
        r = q.run()
        q.destroy()
        if r == Gtk.ResponseType.OK:
            launch("brave-os-power", action)


def main(argv):
    if Gtk is None:
        print(f"GTK unavailable: {_IMPORT_ERROR}", file=sys.stderr)
        return 1
    page = argv[0] if argv and argv[0] in ("input", "power", "retention", "system") else None
    w = Settings(page)
    w.connect("destroy", Gtk.main_quit)
    Gtk.main()
    return 0

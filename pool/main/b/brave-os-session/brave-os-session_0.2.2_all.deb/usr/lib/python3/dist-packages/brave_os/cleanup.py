"""Downloads staging cleanup for brave-os (SPEC.md section 5).

Semantics (see docs/FILE-RETENTION.md):
- Runs as the owning user. Only regular files inside the agreed staging root are deleted.
- A file is eligible when BOTH its content mtime AND the time it was first observed by this tool
  are at least RETENTION_DAYS old. The first-observed time is the safety grace: a newly staged file
  carrying an old mtime survives at least RETENTION_DAYS after it was first seen.
- Identity is (device, inode, mtime_ns). Renaming keeps identity (no renewal). Editing changes the
  mtime, hence the identity, hence a fresh first-observed time (renewed eligibility). Opening or
  uploading changes nothing. Inode reuse by a different file with a different mtime is a new identity.
- Symlinks are never followed, mount boundaries are never crossed, hard-linked files (nlink > 1),
  incomplete downloads, non-regular files and files open in the user's own processes are skipped.
- Missing or corrupt state restarts the grace period for everything (conservative).
- Clock moved backwards, or a gap of more than LONG_GAP_DAYS since the last run: observe only,
  delete nothing this run.
- fd-relative, O_NOFOLLOW operations; identity is re-checked immediately before unlink.
"""
import argparse
import configparser
import json
import logging
import os
import stat
import sys
import time

RETENTION_DAYS = 30
LONG_GAP_DAYS = 60
BACKWARDS_TOLERANCE_S = 24 * 3600
STATE_VERSION = 2
INCOMPLETE_SUFFIXES = (".crdownload", ".part", ".partial", ".download", ".tmp", ".opdownload", ".!qb")
INCOMPLETE_PREFIXES = ("Unconfirmed ", ".com.google.Chrome.", ".org.chromium.Chromium.", ".com.brave.Browser.")
SKIP_NAMES = {".brave-os-retention-notice.txt"}
UNSAFE_FIRST_COMPONENTS = {".config", ".local", ".cache", ".mozilla", ".ssh", ".gnupg", ".pki", ".var", "snap", ".thunderbird", ".Trash", ".brave", ".BraveSoftware"}
DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC | getattr(os, "O_NOCTTY", 0)

log = logging.getLogger("brave-os-cleanup")


class Refusal(Exception):
    """Raised when the staging root is unsafe or not accepted. Nothing is deleted."""


def default_paths():
    home = os.path.expanduser("~")
    cfg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    st = os.environ.get("XDG_STATE_HOME") or os.path.join(home, ".local", "state")
    return {
        "home": home,
        "config": os.path.join(cfg, "brave-os", "cleanup.conf"),
        "state": os.path.join(st, "brave-os", "staging-cleanup.json"),
        "user_dirs": os.path.join(cfg, "user-dirs.dirs"),
    }


def read_kv(path):
    """Tiny key=value reader (no sections). Missing file -> {}."""
    out = {}
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"')
    except FileNotFoundError:
        pass
    return out


def xdg_download_dir(user_dirs_path, home):
    """Resolve XDG_DOWNLOAD_DIR from user-dirs.dirs like xdg-user-dir does; default ~/Downloads."""
    val = read_kv(user_dirs_path).get("XDG_DOWNLOAD_DIR")
    if not val:
        return os.path.join(home, "Downloads")
    val = val.replace("$HOME", home)
    if not os.path.isabs(val):
        return os.path.join(home, "Downloads")
    return os.path.normpath(val)


def resolve_staging_root(home, candidate, accepted_root, uid=None):
    """Return the validated staging root or raise Refusal. Never follows a symlinked root."""
    uid = os.getuid() if uid is None else uid
    home_real = os.path.realpath(home)
    if not candidate or not os.path.isabs(candidate):
        raise Refusal("staging directory is not an absolute path")
    cand = os.path.normpath(candidate)
    if ".." in cand.split(os.sep):
        raise Refusal("staging directory contains '..'")
    if not accepted_root:
        raise Refusal("no accepted staging root recorded in cleanup.conf (safe opt-in missing)")
    if os.path.normpath(accepted_root) != cand:
        raise Refusal("XDG Downloads directory differs from the accepted staging root; refusing")
    try:
        st = os.lstat(cand)
    except FileNotFoundError:
        raise Refusal("staging directory does not exist")
    if stat.S_ISLNK(st.st_mode):
        raise Refusal("staging directory is a symlink")
    if not stat.S_ISDIR(st.st_mode):
        raise Refusal("staging directory is not a directory")
    real = os.path.realpath(cand)
    if real in ("/", home_real) or real == os.path.realpath(os.path.dirname(home_real)):
        raise Refusal("staging directory is home, its parent or /")
    if not real.startswith(home_real + os.sep):
        raise Refusal("staging directory is outside the home directory")
    first = real[len(home_real) + 1:].split(os.sep)[0]
    if first in UNSAFE_FIRST_COMPONENTS or first.startswith(".") and first not in {".brave-os-downloads"}:
        raise Refusal("staging directory is inside a configuration/browser folder")
    if st.st_uid != uid:
        raise Refusal("staging directory is not owned by the current user")
    return cand


def is_incomplete(name):
    low = name.lower()
    return low.endswith(INCOMPLETE_SUFFIXES) or any(name.startswith(p) for p in INCOMPLETE_PREFIXES)


def identity(st):
    return f"{st.st_dev}:{st.st_ino}:{st.st_mtime_ns}"


def load_state(path, now):
    """Load state; on any problem return fresh state (grace restarts) and set a warning flag."""
    fresh = {"version": STATE_VERSION, "root": None, "root_id": None, "last_run": None, "files": {}}
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or data.get("version") != STATE_VERSION or not isinstance(data.get("files"), dict):
            raise ValueError("unexpected structure")
        for k, v in data["files"].items():
            if not isinstance(k, str) or not isinstance(v, (int, float)):
                raise ValueError("bad entry")
        return data, None
    except FileNotFoundError:
        return fresh, "no state file (first run): grace period starts now for all files"
    except (ValueError, OSError, json.JSONDecodeError) as e:
        try:
            os.replace(path, f"{path}.corrupt-{int(now)}")
        except OSError:
            pass
        return fresh, f"state unreadable ({e.__class__.__name__}); restarting grace for all files"


def save_state(path, state):
    d = os.path.dirname(path)
    os.makedirs(d, mode=0o700, exist_ok=True)
    tmp = f"{path}.tmp.{os.getpid()}"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(state, fh, separators=(",", ":"))
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def open_files_in_use(proc="/proc"):
    """(dev, ino) pairs of files opened by processes we can inspect (our own)."""
    busy = set()
    try:
        pids = [p for p in os.listdir(proc) if p.isdigit()]
    except OSError:
        return busy
    for pid in pids:
        fddir = os.path.join(proc, pid, "fd")
        try:
            for fd in os.listdir(fddir):
                try:
                    st = os.stat(os.path.join(fddir, fd))
                except OSError:
                    continue
                if stat.S_ISREG(st.st_mode):
                    busy.add((st.st_dev, st.st_ino))
        except OSError:
            continue
    return busy


class Counts:
    FIELDS = ("seen", "eligible", "deleted", "would_delete", "kept_young", "kept_grace", "skipped_incomplete",
              "skipped_symlink", "skipped_mount", "skipped_hardlink", "skipped_other", "skipped_in_use",
              "skipped_future_mtime", "changed_before_delete", "errors")

    def __init__(self):
        for f in self.FIELDS:
            setattr(self, f, 0)

    def as_dict(self):
        return {f: getattr(self, f) for f in self.FIELDS}


def _walk(dir_fd, root_dev, rel, visit, counts):
    try:
        with os.scandir(dir_fd) as it:
            entries = list(it)
    except OSError as e:
        log.warning("cannot read directory %s: %s", rel or ".", e.strerror)
        counts.errors += 1
        return
    for e in entries:
        name = e.name
        try:
            if e.is_symlink():
                counts.skipped_symlink += 1
                continue
            st = e.stat(follow_symlinks=False)
        except OSError:
            counts.errors += 1
            continue
        if st.st_dev != root_dev:
            counts.skipped_mount += 1
            continue
        if stat.S_ISDIR(st.st_mode):
            try:
                sub = os.open(name, DIR_FLAGS, dir_fd=dir_fd)
            except OSError:
                counts.errors += 1
                continue
            try:
                _walk(sub, root_dev, os.path.join(rel, name), visit, counts)
            finally:
                os.close(sub)
        elif stat.S_ISREG(st.st_mode):
            visit(dir_fd, name, st, os.path.join(rel, name))
        else:
            counts.skipped_other += 1


def run(root, state_path, now=None, dry_run=False, paused=False, verbose=False, retention_days=RETENTION_DAYS,
        proc="/proc"):
    """Perform one cleanup pass over an already-validated root. Returns (Counts, notes)."""
    now = time.time() if now is None else float(now)
    counts = Counts()
    notes = []
    state, warn = load_state(state_path, now)
    if warn:
        notes.append(warn)
    threshold = retention_days * 86400
    delete_allowed = not dry_run and not paused
    last_run = state.get("last_run")
    if last_run is not None:
        if now < last_run - BACKWARDS_TOLERANCE_S:
            notes.append("clock moved backwards since last run; observing only, deleting nothing")
            delete_allowed = False
        elif now - last_run > LONG_GAP_DAYS * 86400:
            notes.append(f"more than {LONG_GAP_DAYS} days since last run (downtime or clock jump); observing only this run")
            delete_allowed = False
    if paused:
        notes.append("cleanup is paused by the user; observing only")
    root_fd = os.open(root, DIR_FLAGS)
    try:
        root_st = os.fstat(root_fd)
        root_id = [root_st.st_dev, root_st.st_ino]
        if state.get("root") != root or state.get("root_id") != root_id:
            if state.get("root") is not None:
                notes.append("staging root was replaced or remounted; restarting grace for all files")
                delete_allowed = False
            state = {"version": STATE_VERSION, "root": root, "root_id": root_id, "last_run": state.get("last_run"), "files": {}}
        old_files = state["files"]
        new_files = {}
        busy = open_files_in_use(proc) if delete_allowed or dry_run else set()

        def visit(dir_fd, name, st, rel):
            counts.seen += 1
            ident = identity(st)
            first_seen = old_files.get(ident)
            if first_seen is None:
                first_seen = now
            new_files[ident] = first_seen
            if name in SKIP_NAMES:
                return
            if is_incomplete(name):
                counts.skipped_incomplete += 1
                return
            if st.st_nlink > 1:
                counts.skipped_hardlink += 1
                return
            mtime = st.st_mtime
            if mtime > now + 86400:
                counts.skipped_future_mtime += 1
                return
            if now - mtime < threshold:
                counts.kept_young += 1
                return
            if now - first_seen < threshold:
                counts.kept_grace += 1
                return
            counts.eligible += 1
            if (st.st_dev, st.st_ino) in busy:
                counts.skipped_in_use += 1
                return
            if not delete_allowed:
                counts.would_delete += 1
                if verbose:
                    log.info("would delete: %s", rel)
                return
            try:
                st2 = os.stat(name, dir_fd=dir_fd, follow_symlinks=False)
            except FileNotFoundError:
                counts.changed_before_delete += 1
                return
            except OSError as e:
                counts.errors += 1
                log.warning("stat failed before delete (%s)", e.strerror)
                return
            if identity(st2) != ident or not stat.S_ISREG(st2.st_mode) or st2.st_nlink > 1:
                counts.changed_before_delete += 1
                return
            try:
                os.unlink(name, dir_fd=dir_fd)
                counts.deleted += 1
                new_files.pop(ident, None)
                if verbose:
                    log.info("deleted: %s", rel)
            except OSError as e:
                counts.errors += 1
                log.warning("delete failed (%s): %s", e.strerror, rel if verbose else "[name withheld]")

        _walk(root_fd, root_st.st_dev, "", visit, counts)
    finally:
        os.close(root_fd)
    state["files"] = new_files
    state["last_run"] = max(now, last_run or 0) if last_run is not None and now < last_run else now
    try:
        save_state(state_path, state)
    except OSError as e:
        counts.errors += 1
        notes.append(f"could not save state: {e.strerror}")
    return counts, notes


def load_config(path):
    kv = read_kv(path)
    paused = kv.get("paused", "false").lower() in ("1", "true", "yes", "on")
    return {"paused": paused, "accepted_root": kv.get("accepted_root", "")}


def write_config(path, paused, accepted_root):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    text = ("# Downloads retention. paused=true disables deletion. accepted_root must equal the resolved\n"
            "# XDG Downloads directory (safe opt-in).\n"
            f"paused={'true' if paused else 'false'}\naccepted_root={accepted_root}\n")
    tmp = f"{path}.tmp.{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="brave-os-staging-cleanup", description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("run", "status"):
        p = sub.add_parser(name)
        p.add_argument("--dry-run", action="store_true", help="report, delete nothing")
        p.add_argument("--now", type=float, help="injected current time (epoch seconds) for tests")
        p.add_argument("--verbose", action="store_true", help="log file names (off by default)")
        p.add_argument("--json", action="store_true")
        p.add_argument("--home", help=argparse.SUPPRESS)
        p.add_argument("--config", help=argparse.SUPPRESS)
        p.add_argument("--state", help=argparse.SUPPRESS)
        p.add_argument("--user-dirs", help=argparse.SUPPRESS)
    sub.add_parser("pause")
    sub.add_parser("resume")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s", stream=sys.stderr)
    paths = default_paths()
    if args.cmd in ("pause", "resume"):
        cfg = load_config(paths["config"])
        write_config(paths["config"], args.cmd == "pause", cfg["accepted_root"])
        print(f"cleanup {'paused' if args.cmd == 'pause' else 'resumed'}")
        return 0
    home = args.home or paths["home"]
    cfg_path = args.config or paths["config"]
    state_path = args.state or paths["state"]
    user_dirs = args.user_dirs or paths["user_dirs"]
    cfg = load_config(cfg_path)
    candidate = xdg_download_dir(user_dirs, home)
    try:
        root = resolve_staging_root(home, candidate, cfg["accepted_root"])
    except Refusal as e:
        msg = {"refused": str(e), "candidate": candidate}
        print(json.dumps(msg) if args.json else f"REFUSED: {e} (candidate: {candidate})")
        return 2
    dry = args.dry_run or args.cmd == "status"
    counts, notes = run(root, state_path, now=args.now, dry_run=dry, paused=cfg["paused"], verbose=args.verbose)
    out = {"root": root, "paused": cfg["paused"], "dry_run": dry, "notes": notes, **counts.as_dict()}
    if args.json:
        print(json.dumps(out))
    else:
        for n in notes:
            print(f"note: {n}")
        print(f"seen={counts.seen} eligible={counts.eligible} deleted={counts.deleted} would_delete={counts.would_delete} "
              f"kept_young={counts.kept_young} kept_grace={counts.kept_grace} skipped_incomplete={counts.skipped_incomplete} "
              f"skipped_in_use={counts.skipped_in_use} errors={counts.errors}")
    return 4 if counts.errors else 0


if __name__ == "__main__":
    sys.exit(main())

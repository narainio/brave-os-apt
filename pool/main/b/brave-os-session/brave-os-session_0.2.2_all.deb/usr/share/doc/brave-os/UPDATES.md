# Updates: how brave-os changes reach an installed machine

brave-os has no updater of its own (SPEC section 7). Everything arrives through APT:

| What | Where it comes from | How it is applied |
|---|---|---|
| Debian packages (kernel, libc, labwc, waybar, …) | deb.debian.org, security.debian.org (Debian's keys) | unattended-upgrades, daily |
| Brave Origin | Brave's signed repository (`Signed-By` keyring) | unattended-upgrades, daily |
| brave-os itself: session, panel, Settings, idle and power policy, Downloads retention, installer launcher, update policy, these documents | the brave-os repository (this document) | unattended-upgrades, daily |

Nothing reboots the machine or closes the browser. The panel shows **Restart needed** when a
Debian update wants a reboot, or when a brave-os update wants a sign-out; both wait for you
(Settings > System). Changes that cannot travel this way: partitioning, LUKS, the installer, the
kernel command line, and anything that needs a new image.

## The brave-os repository

- URL: `https://raw.githubusercontent.com/narainio/brave-os-apt/main` (a public GitHub repository
  holding only the built packages and their signed index). Suite `trixie`, component `main`.
- Signed with the brave-os archive key, ed25519, fingerprint
  `362D 539B BC4F 1B4D 968A  A92C 67E6 D02E B181 856E`, no expiry. APT verifies every `InRelease`
  against `/usr/share/keyrings/brave-os-archive-keyring.gpg` only (`Signed-By`); the key is never in
  the global trust store, and `trusted=yes` is forbidden by lint.
- Two packages, both `Architecture: all`:
  - `brave-os-archive-keyring`: the keyring above and `/etc/apt/sources.list.d/brave-os.sources`.
  - `brave-os-session`: every file under `appliance/rootfs` plus `/usr/share/doc/brave-os`. Files
    under `/etc` are conffiles, so a local edit is kept and the package's version is installed only
    where nothing was changed. Per-user settings under `~/.config/brave-os` are never touched.
- unattended-upgrades accepts the repository through `origin=brave-os,codename=trixie`
  (`/etc/apt/apt.conf.d/52brave-os-unattended-upgrades`).
- After `brave-os-session` is upgraded its postinst writes `/run/brave-os/session-restart-required`;
  the panel shows "Restart needed" until a session newer than that flag starts (the session script
  writes `$XDG_RUNTIME_DIR/brave-os/session-started`). A sign-out and sign-in is enough; a restart
  also works.

## Releasing a change (builder session)

1. Edit `appliance/rootfs` (or docs), add a line to `docs/CHANGELOG.md`, bump `BRAVE_OS_VERSION` in
   `config/release.conf`, commit.
2. `make lint && make test-unit` (no root).
3. `make apt-repo`: builds `out/debs/*.deb`, indexes and signs `out/apt-repo/`, verifies it. The
   secret key comes from the builder environment secret `BRAVE_OS_APT_SIGNING_KEY_B64` (base64 of
   the ASCII-armoured secret key) or from `BRAVE_OS_GNUPGHOME`. It is never stored in git.
4. `scripts/apt-repo.py publish --git-remote https://github.com/narainio/brave-os-apt.git`
   (`out/apt-repo` is a checkout of that repository's `main`; the command verifies, commits and
   pushes). Machines pick the change up at their next daily run, or at once through Settings >
   System > Check for updates now followed by the daily timer, or `sudo unattended-upgrade` on tty3.
5. A new image (`make build`) is only needed when something outside the packages changes. The
   image build installs the same debs from `config/packages.chroot` and refuses to build unless the
   published repository already offers those exact versions (hook 0090), so image and repository
   never disagree.

Keep the pool small: `apt-repo.py build --keep 3` keeps the three newest versions of each package.

## One-time adoption on a machine installed from build 7 or earlier

Images before 0.2.0 copied the session files into the image without a package, so nothing could
update them. Once, by hand (the live session cannot do this; the installed machine can):

1. In Brave, download the two files below into Downloads (or copy them from a USB stick). Use the
   newest version in the pool; 0.2.2 at the time of writing:
   `https://raw.githubusercontent.com/narainio/brave-os-apt/main/pool/main/b/brave-os-archive-keyring/brave-os-archive-keyring_0.2.2_all.deb`
   `https://raw.githubusercontent.com/narainio/brave-os-apt/main/pool/main/b/brave-os-session/brave-os-session_0.2.2_all.deb`
2. Switch to a text console with Ctrl+Alt+F3, sign in with your user and password, then:

```
cd ~/Downloads
sha256sum brave-os-*.deb
sudo apt install -o Dpkg::Options::=--force-confnew ./brave-os-archive-keyring_0.2.2_all.deb ./brave-os-session_0.2.2_all.deb
sudo apt update && apt policy brave-os-session
```

   Compare the checksums with the `SHA256` lines for these files in
   `https://raw.githubusercontent.com/narainio/brave-os-apt/main/dists/trixie/main/binary-amd64/Packages`
   before installing.
   `--force-confnew` is needed this one time: the files under `/etc` already exist unowned, and
   dpkg would otherwise treat them as your edits and keep the old versions. `apt policy` must show
   the repository as the candidate's origin.
3. Ctrl+Alt+F7 (or F1) back to the desktop, then Settings > System > Restart, or sign out and in.
   From now on updates arrive on their own.

A warning that the download "is performed unsandboxed as root" is apt complaining that `_apt`
cannot read your Downloads directory; it is harmless for local files.

## Key custody and rotation

- The secret key exists in two places only: the owner's password manager and the builder
  environment secret `BRAVE_OS_APT_SIGNING_KEY_B64`. Builder containers are disposable; a session
  that lacks the secret can build packages but cannot publish them.
- Losing the key is recoverable but manual: generate a new key, ship it in a new
  `brave-os-archive-keyring` signed with the old key if the old key still exists, otherwise repeat
  the one-time adoption above with the new keyring package on every machine.
- Rotation while the old key exists is routine: put both public keys in the keyring package, publish
  signed with the old key, wait until every machine has it, then sign with the new key and drop the
  old one in the following keyring package.
- The repository has no `Valid-Until`, so a machine offline for months still accepts the last index
  it can fetch; the trade-off is that a stale mirror could serve old packages, which APT would not
  flag. With a single origin repository that is accepted for v1.

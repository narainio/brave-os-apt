# Recovery and preparation

## Before any physical installation
1. **Flex recovery USB:** create a ChromeOS Flex recovery USB with the Recovery Utility on another
   machine (or before erasing). Verify it boots the laptop.
2. **Backups:** anything local on the Flex install is lost. Cloud-synced data is unaffected.
3. **Firmware notes:** write down Secure Boot state and boot order so you can restore them.
4. **Second test:** boot the brave-os USB once more and confirm Gate 4 results before installing.

## Recovering from a bad installed system
- **Previous kernel / recovery mode:** hold Shift or press Esc at boot for the GRUB menu →
  "Advanced options" lists the previous kernel and recovery entries (kept by configuration).
- **Text console:** Ctrl+Alt+F3, log in with your user, `sudo` for maintenance (apt, journalctl).
- **Live USB rescue:** boot the brave-os USB; on tty3 `sudo cryptsetup open /dev/nvme0n1p2 root`
  then `sudo mount /dev/mapper/root /mnt` to reach your files (adjust the device name from
  `lsblk`). Downloads live in `/mnt/home/<user>/Downloads`.
- **Back to ChromeOS Flex:** boot the Flex recovery USB and follow its prompts (erases the disk).

## What is not recoverable
- Anything from a live session (nonpersistent by design): no browser logins, passwords or
  downloads survive a live reboot. This is not a data-recovery promise.
- A forgotten LUKS passphrase. There is no backdoor and no TPM escrow.

## Writing the USB on another machine (fallback, not the requested path)
`dd if=brave-os-...iso of=/dev/sdX bs=4M status=progress conv=fsync` on Linux, or Rufus in
"DD image" mode on Windows. Verify the device name three times; this erases the target.

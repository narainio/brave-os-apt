# Downloads retention (30-day cleanup)

**Plain-language notice shown in the product:** Downloads are temporary. Eligible files are
permanently deleted after 30 days. Opening or renaming does not extend retention.

## Exactly what happens
- Staging root: your `~/Downloads` (the XDG download directory). Every Brave profile downloads
  there by default; all profiles share it. Nothing else is ever touched.
- A per-user systemd timer (`brave-os-staging-cleanup.timer`) runs daily, with catch-up at the next
  login after downtime (`Persistent=true`). It never runs in the live session, and never needs you
  to stay logged in or the machine to wake up.
- A regular file is deleted when **both** are true: its contents were last modified at least 30
  days ago, **and** the cleanup first noticed the file at least 30 days ago.
- The second condition is the **safety grace**: a file you copy or download today that carries an
  old modification date is kept for at least 30 days from today. Consequently a file may live
  longer than 30 days after its modification date, never shorter.
- The cleanup identifies a file by device, inode and modification time. Renaming or moving it
  within Downloads keeps that identity (no extension). Editing changes the modification time, so
  the 30 days restart. Opening, previewing or uploading a file changes nothing.
- Skipped, always: incomplete downloads (`.crdownload`, `Unconfirmed *.crdownload`, `.part`,
  `.tmp`, ...), directories themselves (they stay, even when emptied), symlinks (never followed),
  anything on another filesystem mounted under Downloads, hard-linked files, files currently open
  in your own programs, files with a modification time in the future.
- Immediately before deleting, the file is checked again; if it changed or was replaced it is left
  alone. There is still a tiny window between that check and the delete; a file replaced within it
  by another file of identical identity could be lost. In practice this needs identical inode and
  nanosecond mtime.
- State lives in `~/.local/state/brave-os/staging-cleanup.json` (mode 0600, no file names, no
  contents). If it is missing or corrupt, the grace period restarts for everything.
- Clock moved backwards, or more than 60 days since the last run: that run only observes;
  deletions resume on the next daily run. After a long time switched off, deletion therefore
  resumes the day after the first login.
- Refuses to run if `~/Downloads` is a symlink, is not owned by you, or if the XDG download
  directory was pointed somewhere else than the directory recorded in
  `~/.config/brave-os/cleanup.conf` (`accepted_root`). To move the staging directory on purpose,
  edit both and the next run starts a fresh grace period.
- Pause: Settings → Downloads retention, or `brave-os-staging-cleanup pause` / `resume`. While
  paused nothing is deleted; files are still observed, so unpausing does not grant a new grace.
- Dry run: `brave-os-staging-cleanup status` (also the "Check now" button). Counts only; add
  `--verbose` to see names.

## Not a backup policy
This is a convenience that keeps a staging folder from growing. It is not secure erasure, and it
does not protect against your own deletions. Keep anything important elsewhere.

## Optional enterprise-policy fallback (not applied)
If a future Brave Origin release stops defaulting new profiles to the XDG download directory, the
documented, supported mechanism is a *recommended* (user-changeable) Chromium policy
`DownloadDirectory` in the browser's `policies/recommended/` directory. It is not shipped because
the default already lands in `~/Downloads` and SPEC.md prefers not to use policies.

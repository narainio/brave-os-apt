# Security notes

## What is enforced
- **Browser sandbox:** Brave Origin runs as the logged-in user with Chromium's sandbox enabled;
  no sandbox-disabling flag anywhere (lint and the build's finalize hook fail if one appears).
- **Package verification:** Debian and Brave repositories are HTTPS and APT verifies InRelease
  signatures; the Brave key is a `Signed-By` keyring scoped to its repository, pinned to a
  fingerprint recorded in `config/release.conf`. No piping of downloaded scripts into a shell, no unsigned repositories.
- **Encryption at rest (installed):** LUKS1 container holding `/` including `/boot`; only the EFI
  System Partition (FAT32, ~512 MiB) is plaintext. GRUB prompts for the passphrase; the initramfs
  re-unlocks with a keyfile stored *inside* the encrypted root (`/crypto_keyfile.bin`, root-only,
  embedded in the initramfs which also lives inside the encrypted root). No swap partition; zram
  only; hibernation disabled.
- **Credential storage:** gnome-keyring unlocked by PAM at login; Brave is told to use it
  (`--password-store=gnome-libsecret`) instead of Chromium's obfuscated "basic" store.
- **Accounts:** installer-created ordinary user in `sudo`; root locked; no autologin; no
  passwordless sudo; the live user, its sudo exception and the installer are removed at install.
- **No remote access:** no ssh server; `0200` hook purges it if a Recommends pulls it in.
- **Lock:** swaylock on Super+L, idle (10 min default) and always before sleep; lid close suspends.
- **Updates:** unattended security and stable updates plus Brave by repository site; no automatic
  reboot; a panel badge asks for a restart.

## Known limitations
- LUKS1 (PBKDF2) instead of LUKS2/Argon2id because GRUB unlocks `/boot`. Documented tradeoff; a
  future split with an unencrypted `/boot` and LUKS2 root is possible but changes the layout.
- The GRUB passphrase prompt is slow (seconds) by design of PBKDF2 iteration counts.
- Two prompts at boot (passphrase, login). TPM unlock is out of scope.
- The live session has a fixed, documented password (`live`); it holds no secrets and vanishes.
- Secure Boot: the image includes Debian's signed shim/GRUB/kernel chain, but end-to-end
  verification is NOT-RUN until an OVMF Secure Boot VM boot and the laptop test.
- The retention cleanup is a convenience, not secure erasure.
- Processes of other users (none expected) are not visible to the in-use check of the cleanup.

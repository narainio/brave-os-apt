# Changelog

Versions are `BRAVE_OS_VERSION` in `config/release.conf`; the same number names the appliance
packages and the image. Dates are UTC.

## 0.2.3 (2026-11-01)

- `brave-os-session` no longer ships `/etc/apt/apt.conf.d/20auto-upgrades`; unattended-upgrades
  writes that file itself and the duplicate made dpkg prompt during the image build. The autoclean
  interval moved into `52brave-os-unattended-upgrades`.

## 0.2.2 (2026-11-01)

- `brave-os-session` diverts waybar's `/etc/xdg/waybar/style.css` instead of overwriting it; 0.2.0
  and 0.2.1 could not be installed next to Debian's waybar package (dpkg refused the shared path).

## 0.2.1 (2026-11-01)

- Settings > System lists the installed brave-os package versions.
- `brave-os-session` no longer depends on `psmisc`, which build 7 did not ship, so adopting the
  packages on a build 7 machine needs nothing from the Debian mirrors.

## 0.2.0 (2026-11-01)

- The session, panel, Settings, idle and power policy, Downloads retention, installer launcher and
  update policy now ship as the `brave-os-session` package; `brave-os-archive-keyring` carries the
  signed brave-os repository. Installed machines receive future versions through
  unattended-upgrades (docs/UPDATES.md, D-29).
- The panel and Settings > System show "Restart needed" after a brave-os update until a new session
  starts; Settings > System > Check for updates now lists the brave-os packages.
- Images before 0.2.0 need the one-time adoption in docs/UPDATES.md.

## 0.1.0-prototype, builds 1 to 7 (2026-10-05)

- First images: Debian 13.7, labwc, Brave Origin, Calamares erase-disk LUKS install. Verified in
  VMs; build 7 published and installed on the X1 Nano.
